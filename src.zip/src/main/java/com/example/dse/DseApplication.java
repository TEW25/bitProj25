package com.example.dse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DseApplication.class, args);
	}

}
