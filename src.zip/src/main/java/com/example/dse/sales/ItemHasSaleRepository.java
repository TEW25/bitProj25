package com.example.dse.sales;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemHasSaleRepository extends JpaRepository<ItemHasSale, Integer> {
}
